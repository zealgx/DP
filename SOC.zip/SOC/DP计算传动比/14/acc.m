clc
clear
load a1.mat;
format long
k=0;
c3=[];
for j=1:19195
    if (abs(a1(j,1)-k)<=0.000001)
        c3(k+1)=a1(j,2);
        k=k+1
    else
        continue;
    end
    j
end
c3=c3'
        
        
    