clc
clear
load a3.mat;
format long
k=0;
c3=[];
for j=1:24916
    if (abs(a3(j,1)-k)<=0.000001)
        c3(k+1)=a3(j,2);
        k=k+1
    else
        continue;
    end
    j
end
c3=c3'
        
        
    