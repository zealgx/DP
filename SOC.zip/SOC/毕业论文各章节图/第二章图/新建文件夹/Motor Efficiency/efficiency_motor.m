clc
clear
load efficiency.mat
load efficiency_ram.mat
load efficiency_tq.mat
load Motor_RPM.mat
load Motor_Tmax.mat
load Motor_eff_tq    %ת��
load Motor_eff_n     %ת��
load Motor_eff_eff   %Ч�ʵĵ���
load P              %��ζ���ʽ��ϵ�� p1 p2 p3 p4 p5 p6
% mesh(efficiency_ram,efficiency_tq,efficiency);
% figure;
% [c,h]=contour(efficiency_ram,efficiency_tq,efficiency,[67,68,70,75,80,82,84,86,88,90,91,92,93,94,95,96]);
% set(h,'ShowText','on');
% hold on
% plot(Motor_RPM,Motor_Tmax,'b','LineWidth',2)
% figure
% contourf(efficiency_ram,efficiency_tq,efficiency,[67,68,70,75,80,82,84,86,88,90,91,92,93,94,95,96]) %�ȸ���ͼ      ���ϲ�ɫ��
% hold on
% plot(Motor_RPM,Motor_Tmax,'b','LineWidth',2)
% figure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
%ת����Ч�ʵĵ���
for i=1:22
    for j=1:25
       efficiency(i,j)=efficiency(i,j)*0.95;
    end
end
[c,h]=contour(efficiency_ram,efficiency_tq,efficiency,[67,68,70,75,80,82,84,86,88,90,91,92,93,94,95,95.8]);
set(h,'ShowText','on');
hold on
plot(Motor_RPM,Motor_Tmax,'b','LineWidth',2);
figure
[c,h]=contour(Motor_eff_n,Motor_eff_tq,Motor_eff_eff,[100/67,100/68,100/70,100/75,100/80,100/82,100/84,100/86,100/88,100/90,100/91,100/92,100/93,100/94,100/95,100/95.8]);
set(h,'ShowText','on');
hold on
plot(Motor_RPM,Motor_Tmax,'b','LineWidth',2)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot(n/1000,itaa,'r*')       %Ч�����ʹ�ó���
% hold on 
% x=0:0.05:12;
%  p1 = 0.00035191
%   p2 = -0.0066927
%   p3 = 0.047586
%   p4 = -0.15355
%   p5 = 1.2357	
% y =p1*x.^4+p2*x.^3+p3*x.^2+p4*x+p5; 
% plot(x,y)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%���Ч��
% T_m=[0 20 30 40 50 60 70 80 100 120 140 160 180 200];
% N_m=[0,500,1000,1500,2000,2500,3000,3500,4000,4500,5000,5500,6000,6500,7000,7500,8000,8500,9000,9500,10000,10500,11000,11500,12000];
% ita=ones(14,25);
% for i=1:14
%     for j=1:25
%         p1=P(i,1);
%         p2=P(i,2);
%         p3=P(i,3);
%         p4=P(i,4);
%         p5=P(i,5);
%         p6=P(i,6);
%         x=N_m(j)/1000;
%         T=interp1(Motor_RPM,Motor_Tmax,N_m(j),'spline');
%         if T_m(i)>=(T+1)
%            ita(i,j)=ita(i,j-1);
%         else
%         ita(i,j)=p1*x^5+p2*x^4+p3*x^3+p4*x^2+p5*x+p6; 
%         end
%     end
% end
