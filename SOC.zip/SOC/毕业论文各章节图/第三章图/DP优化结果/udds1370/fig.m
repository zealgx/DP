clc
clear
load Re_ig
load Re_Tm
load Re_SOC
load v
t=1:1371;
% subplot(4,1,1);
 plot(t,v)
% subplot(4,1,2);
% plot(t,Re_ig)
% subplot(4,1,3);
% plot(t,Re_SOC)
% subplot(4,1,4);
% plot(t,Re_Tm)