clc
clear
load SOC_min
load SOC_max
t=1:1371;
plot(t,SOC_max)
hold on
plot(t,SOC_min)
figure
a=[];
a(1)=0.75;
for i=2:1371
    if SOC_min(i)==SOC_min(i-1)
        a(i)=a(i-1);
    else
        a(i)=SOC_min(i)-i*0.1/800;
    end
end
plot(t,SOC_max)
hold on
plot(t,a)