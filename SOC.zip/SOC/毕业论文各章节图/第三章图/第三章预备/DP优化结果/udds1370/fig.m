clc
clear
load Re_ig
load Re_Tm
load Re_SOC
load v
t=1:1371;
a=[];
a(1)=0.75;
for i=2:1371
    if Re_SOC(i)==Re_SOC(i-1)
        a(i)=a(i-1);
    else
        a(i)=Re_SOC(i)-i*(0.7009-0.687)/800;
    end
end
subplot(4,1,1);
plot(t,v)
subplot(4,1,2);
plot(t,Re_ig)
subplot(4,1,3);
plot(t,a)
subplot(4,1,4);
plot(t,Re_Tm)