clc
clear
load soc
load u1
load u2
plot(soc,u1,'r')
hold on
plot(soc,u2,'r--')