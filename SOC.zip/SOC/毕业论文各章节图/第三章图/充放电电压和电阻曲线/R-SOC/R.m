clc
clear
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����ͼ
load soc 
load R1
load R2
plot(soc,R1,'r')
hold on;
plot(soc,R2,'r--')