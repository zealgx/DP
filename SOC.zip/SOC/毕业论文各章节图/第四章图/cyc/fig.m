clc
clear
load v1
load v2
load v3
t1=1:661;
t2=1:1181;
t3=1:1371;
subplot(3,1,1);
plot(t2,v2)
subplot(3,1,2);
plot(t3,v3)
subplot(3,1,3);
plot(t1,v1)