clc
clear
load AA
load BB
load CC
BB=BB/3.96;
CC=CC/3.96;
x=2.35:0.1:3.65;
x=x';
y=0.52:0.1:1.72;
z=ones(14,13);
for i=1:14
    for j=1:13
        z(i,j)=griddata(BB,CC,AA,x(i),y(j),'cubic');
    end
end
