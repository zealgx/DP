clc
clear
load soc1015
load soc_duibi
a=[];
a(1)=0.75;
for i=2:661
    if(soc1015(i)==soc1015(i-1))
        a(i)=a(i-1);;
    else
    a(i)=soc1015(i)+i*(0.7368-0.7342)/661;
    %soc_duibi(i)=soc_duibi(i)+i*(0.7347-0.7321)/661;
    end
end
t=1:661;
plot(t,a,'r')
hold on
plot(t,soc_duibi)
figure
load socnedc
load soc_duibi2
for i=1:1181
    socnedc(i)=socnedc(i)-i*(0.7052-0.6925)/1181;
    soc_duibi2(i)=soc_duibi2(i)-i*(0.6986-0.6835)/1181;
end
t=1:1181;
plot(t,socnedc,'r')
hold on
plot(t,soc_duibi2)
figure
load socudds
load soc_duibi3
for i=1:1181
    socudds(i)=socudds(i)-i*(0.7053-0.6847)/1371;
    soc_duibi3(i)=soc_duibi3(i)-i*(0.699-0.6749)/1371;
end
t=1:1371;
plot(t,socudds,'r')
hold on
plot(t,soc_duibi3)
