clc
clear
load soc1015
load soc_duibi


a=[];
b=[];
a(1)=0.75;
b(1)=0.75;
for i=2:661
    if soc1015(i)==soc1015(i-1)
        a(i)=a(i-1);
    else
        a(i)=soc1015(i)-(0.7342-0.7368)*i/661;
    end
end
for i=2:661
    if soc_duibi(i)==soc_duibi(i-1)
        b(i)=b(i-1);
    else
        b(i)=soc_duibi(i)-(0.7321-0.7347)*i/661;
    end
end



t=1:661;
plot(t,a,'r')
hold on
plot(t,b)
figure
load socnedc
load soc_duibi2
t=1:1181;
a=[];
b=[];
a(1)=0.75;
b(1)=0.75;
for i=2:1181
    if socnedc(i)==socnedc(i-1)
        a(i)=a(i-1);
    else
        a(i)=socnedc(i)-(0.7052-0.6925)*i/1181;
    end
end
for i=2:1181
    if soc_duibi2(i)==soc_duibi2(i-1)
        b(i)=b(i-1);
    else
        b(i)=soc_duibi2(i)-(0.6986-0.6835)*i/1181;
    end
end
plot(t,a,'r')
hold on
plot(t,b)
figure
load socudds
load soc_duibi3
t=1:1371;
a=[];
b=[];
a(1)=0.75;
b(1)=0.75;
for i=2:1371
    if socudds(i)==socudds(i-1)
        a(i)=a(i-1);
    else
        a(i)=socudds(i)-(0.7052-0.6847)*i/1371;
    end
end
for i=2:1371
    if soc_duibi3(i)==soc_duibi3(i-1)
        b(i)=b(i-1);
    else
        b(i)=soc_duibi3(i)-(0.6990-0.6749)*i/1371;
    end
end
plot(t,a,'r')
hold on
plot(t,b)

