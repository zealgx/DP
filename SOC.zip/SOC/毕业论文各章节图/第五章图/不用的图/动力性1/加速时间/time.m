clc
clear
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% a=[0 50 80 100];
% b=[0 4.5 10.927 18.134 ];
% c=[0 4.905 12.014 22.545];
% plot(a,b,'*')
% hold on
% plot(a,c,'*')
load u
load t1
load t2
plot(u,t1,'r')
hold on
plot(u,t2,'b--')