clc
clear
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%������߳���
load u1
load u2
load T1
load T2
load u3
load ft
plot(u1,T1*6800/5000,'r')
hold on
plot(u2,T2*6800/5000,'b--')
hold on
plot(u3,ft*6800/5000)
axis([0 160 0 7500])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����λ��߳���
figure
load x
load y
plot(x,y)
hold on
plot(u3,ft*6800/5000)
axis([0 160 0 7500])
