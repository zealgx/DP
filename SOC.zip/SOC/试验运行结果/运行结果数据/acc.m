clc
clear
load a1.mat;
format long
k=0;
c1=[];
for j=1:20808
    if (abs(a1(j,1)-k))<=0.000001
        c1(k+1)=a1(j,2);
        k=k+1
    else
        continue;
    end
    j
end
c1
        
        
    