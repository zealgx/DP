clc
clear
load NEDC_v.mat
load UDDS_v.mat
load Japan_v.mat
load NEDC_acc.mat
load UDDS_acc.mat
load Japan_acc.mat
load NEDC_gearatio.mat
load UDDS_gearatio.mat
load Japan_gearatio.mat
for i=6:1176
    if (NEDC_gearatio(i)==1&NEDC_gearatio(i+1)==2)
        for j=-5:5
          plot(NEDC_v(i+j),NEDC_acc(i+j),'r*')
          hold on
        end
    end
end
for i=6:1366
   if (UDDS_gearatio(i)==1&UDDS_gearatio(i+1)==2)
        for j=-5:5
          plot(UDDS_v(i+j),UDDS_acc(i+j),'r*')
          hold on
        end
   end
end
for i=6:1366
    if (Japan_gearatio(i)==1&Japan_gearatio(i+1)==2)
        for j=-5:5
          plot(Japan_v(i+j),Japan_acc(i+j),'r*')
          hold on
        end
    end
end
