clc
clear
load NEDC_v.mat
load UDDS_v.mat
load Japan_v.mat
load NEDC_acc.mat
load UDDS_acc.mat
load Japan_acc.mat
load NEDC_gearatio.mat
load UDDS_gearatio.mat
load Japan_gearatio.mat
for i=1:1181
    if(NEDC_gearatio(i)==1)
   plot(NEDC_v(i),NEDC_acc(i),'r*')
   hold on
    else plot(NEDC_v(i),NEDC_acc(i),'b*')
        hold on
   end;      
end
for i=1:661
     if(Japan_gearatio(i)==1)
    plot(Japan_v(i),Japan_acc(i),'ro')
    hold on
    else plot(Japan_v(i),Japan_acc(i),'bo')
        hold on
    end;      
end
for i=1:1371
     if(UDDS_gearatio(i)==1)
    plot(UDDS_v(i),UDDS_acc(i),'r<')
   hold on
  else plot(UDDS_v(i),UDDS_acc(i),'b<')
       hold on
    end;      
end
%x=[6.111,6.111,8.55, ]
%y=[0,0.3,0.36,]

