clc
clear
load a2.mat;
format long
k=0;
c3=[];
for j=1:19262
    if (abs(a2(j,1)-k)<=0.000001)
        c3(k+1)=a2(j,2);
        k=k+1
    else
        continue;
    end
    j
end
c3
        
        
    